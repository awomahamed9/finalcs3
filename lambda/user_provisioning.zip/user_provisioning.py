import json
import boto3
import os
import time
import random
import string
from datetime import datetime

# AWS clients
dynamodb = boto3.client('dynamodb')
ec2 = boto3.client('ec2')
ses = boto3.client('ses')

# Environment variables
DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE']
SES_SENDER_EMAIL = os.environ['SES_SENDER_EMAIL']
OPENVPN_SERVER_IP = os.environ['OPENVPN_SERVER_IP']
SUBNET_ID = os.environ['SUBNET_ID']
SECURITY_GROUP_ID = os.environ['SECURITY_GROUP_ID']
AMI_ID = os.environ['AMI_ID']
KEY_NAME = os.environ['KEY_NAME']

def lambda_handler(event, context):
    """
    Lambda function triggered by DynamoDB Stream when new employee is added.
    Launches a dedicated EC2 virtual desktop for the employee.
    """
    print(f"Received event: {json.dumps(event)}")
    
    for record in event['Records']:
        if record['eventName'] == 'INSERT':
            # Extract employee data from DynamoDB Stream
            new_image = record['dynamodb']['NewImage']
            
            employee_id = new_image['id']['S']
            name = new_image['name']['S']
            email = new_image['email']['S']
            username = new_image['username']['S']
            role = new_image['role']['S']
            department = new_image['department']['S']
            processed = new_image.get('processed', {}).get('BOOL', False)
            
            # Skip if already processed
            if processed:
                print(f"Employee {employee_id} already processed, skipping")
                continue
            
            print(f"Processing new employee: {name} ({username})")
            
            try:
                # Step 1: Generate random password
                password = generate_password()
                print(f"Generated password for {username}")
                
                # Step 2: Launch dedicated EC2 virtual desktop
                instance_id, private_ip = launch_virtual_desktop(
                    employee_id, name, username, password, department
                )
                
                if not instance_id:
                    raise Exception(f"Failed to launch EC2 instance for {username}")
                
                print(f"Successfully launched EC2 instance: {instance_id} ({private_ip})")
                
                # Step 3: Wait for instance to be running
                wait_for_instance_running(instance_id)
                
                # Step 4: Send email with credentials
                send_email_success = send_credentials_email(
                    name, email, username, password, private_ip
                )
                
                if not send_email_success:
                    print(f"Warning: Failed to send email to {email}, but instance created")
                
                print(f"Successfully sent email to: {email}")
                
                # Step 5: Update DynamoDB with instance info
                update_employee_status(
                    employee_id, 
                    processed=True, 
                    instance_id=instance_id,
                    private_ip=private_ip
                )
                print(f"Marked employee {employee_id} as processed")
                
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'message': f'Successfully provisioned desktop for {username}',
                        'employee_id': employee_id,
                        'instance_id': instance_id,
                        'private_ip': private_ip
                    })
                }
                
            except Exception as e:
                print(f"Error processing employee {employee_id}: {str(e)}")
                return {
                    'statusCode': 500,
                    'body': json.dumps({
                        'error': str(e),
                        'employee_id': employee_id
                    })
                }

def generate_password(length=12):
    """Generate a random secure password"""
    characters = string.ascii_letters + string.digits + "!@#$%"
    password = ''.join(random.choice(characters) for i in range(length))
    
    # Ensure it has at least one of each type
    if not any(c.isupper() for c in password):
        password = password[:-1] + random.choice(string.ascii_uppercase)
    if not any(c.isdigit() for c in password):
        password = password[:-1] + random.choice(string.digits)
    
    return password

def launch_virtual_desktop(employee_id, name, username, password, department):
    """
    Launch a dedicated EC2 instance for the employee with Ubuntu + XFCE + RDP
    """
    try:
        # User data script to set up desktop environment
        user_data = f"""#!/bin/bash
set -e

# Update system
apt-get update
apt-get upgrade -y

# Install XFCE desktop (lightweight)
apt-get install -y xfce4 xfce4-goodies

# Install xrdp for RDP access
apt-get install -y xrdp

# Configure xrdp to use XFCE
echo "xfce4-session" > /etc/skel/.xsession

# Enable and start xrdp
systemctl enable xrdp
systemctl start xrdp

# Allow RDP through firewall
ufw allow 3389/tcp || true

# Create user with home directory
useradd -m -s /bin/bash -c '{name}' {username}

# Set password
echo '{username}:{password}' | chpasswd

# Add user to sudo group (optional)
# usermod -aG sudo {username}

# Create .xsession for user
echo 'xfce4-session' > /home/{username}/.xsession
chown {username}:{username} /home/{username}/.xsession

# Install useful tools
apt-get install -y firefox libreoffice vim git

# Disable password expiration for initial setup
chage -I -1 -m 0 -M 99999 -E -1 {username}

echo "Virtual Desktop setup completed for {username}" > /var/log/desktop-setup.log
"""

        # Launch EC2 instance
        response = ec2.run_instances(
            ImageId=AMI_ID,
            InstanceType='t3.medium',
            KeyName=KEY_NAME,
            MinCount=1,
            MaxCount=1,
            NetworkInterfaces=[{
                'SubnetId': SUBNET_ID,
                'DeviceIndex': 0,
                'AssociatePublicIpAddress': False,
                'Groups': [SECURITY_GROUP_ID]
            }],
            UserData=user_data,
            TagSpecifications=[
                {
                    'ResourceType': 'instance',
                    'Tags': [
                        {'Key': 'Name', 'Value': f'virtual-desktop-{username}'},
                        {'Key': 'Employee', 'Value': name},
                        {'Key': 'EmployeeId', 'Value': employee_id},
                        {'Key': 'Department', 'Value': department},
                        {'Key': 'Purpose', 'Value': 'EmployeeDesktop'}
                    ]
                }
            ],
            BlockDeviceMappings=[
                {
                    'DeviceName': '/dev/sda1',
                    'Ebs': {
                        'VolumeSize': 30,
                        'VolumeType': 'gp3',
                        'DeleteOnTermination': True,
                        'Encrypted': True
                    }
                }
            ]
        )
        
        instance_id = response['Instances'][0]['InstanceId']
        private_ip = response['Instances'][0]['PrivateIpAddress']
        
        print(f"Launched instance {instance_id} with IP {private_ip}")
        
        return instance_id, private_ip
        
    except Exception as e:
        print(f"Error launching EC2 instance: {str(e)}")
        return None, None

def wait_for_instance_running(instance_id, max_attempts=30):
    """
    Wait for EC2 instance to reach 'running' state
    """
    try:
        for attempt in range(max_attempts):
            response = ec2.describe_instances(InstanceIds=[instance_id])
            state = response['Reservations'][0]['Instances'][0]['State']['Name']
            
            print(f"Instance {instance_id} state: {state}")
            
            if state == 'running':
                print(f"Instance {instance_id} is now running")
                return True
            
            time.sleep(10)
        
        print(f"Instance {instance_id} did not reach running state in time")
        return False
        
    except Exception as e:
        print(f"Error waiting for instance: {str(e)}")
        return False

def send_credentials_email(name, email, username, password, private_ip):
    """
    Send welcome email with RDP credentials via SES
    """
    try:
        first_name = name.split()[0]
        
        subject = f"Welcome to Innovatech - Your Dedicated Virtual Desktop"
        
        html_body = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background: #2563eb; color: white; padding: 20px; text-align: center; }}
                .content {{ background: #f9fafb; padding: 30px; border-radius: 8px; margin-top: 20px; }}
                .credentials {{ background: white; padding: 20px; border-left: 4px solid #2563eb; margin: 20px 0; }}
                .credential-item {{ margin: 10px 0; }}
                .label {{ font-weight: bold; color: #374151; }}
                .value {{ font-family: monospace; background: #f3f4f6; padding: 5px 10px; border-radius: 4px; }}
                .steps {{ margin-top: 30px; }}
                .step {{ margin: 15px 0; padding-left: 30px; }}
                .warning {{ background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; }}
                .info {{ background: #dbeafe; border-left: 4px solid #2563eb; padding: 15px; margin: 20px 0; }}
                .footer {{ text-align: center; margin-top: 30px; color: #6b7280; font-size: 12px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Welcome to Innovatech!</h1>
                </div>
                
                <div class="content">
                    <p>Hi {first_name},</p>
                    
                    <p>Your dedicated virtual desktop has been provisioned and is ready to use!</p>
                    
                    <div class="info">
                        <strong>🖥️ Your Personal Desktop:</strong> You have your own dedicated virtual machine that only you can access.
                    </div>
                    
                    <div class="credentials">
                        <h3>Your Login Credentials</h3>
                        <div class="credential-item">
                            <span class="label">Username:</span>
                            <span class="value">{username}</span>
                        </div>
                        <div class="credential-item">
                            <span class="label">Password:</span>
                            <span class="value">{password}</span>
                        </div>
                        <div class="credential-item">
                            <span class="label">VPN Server:</span>
                            <span class="value">{OPENVPN_SERVER_IP}</span>
                        </div>
                        <div class="credential-item">
                            <span class="label">Your Desktop Server:</span>
                            <span class="value">{private_ip}:3389</span>
                        </div>
                    </div>
                    
                    <div class="warning">
                        <strong>⚠️ Important:</strong> Please save these credentials securely. Your desktop may take 5-10 minutes to fully boot up.
                    </div>
                    
                    <div class="steps">
                        <h3>How to Connect</h3>
                        
                        <div class="step">
                            <strong>Step 1: Connect to VPN</strong>
                            <ul>
                                <li>Download OpenVPN Connect client from <a href="https://openvpn.net/client/">openvpn.net/client</a></li>
                                <li>Contact IT to receive your VPN configuration file (.ovpn)</li>
                                <li>Import the configuration and connect to the VPN</li>
                            </ul>
                        </div>
                        
                        <div class="step">
                            <strong>Step 2: Connect to Your Desktop</strong>
                            <ul>
                                <li>Once connected to VPN, open Microsoft Remote Desktop</li>
                                <li>Add a new connection with server: <code>{private_ip}:3389</code></li>
                                <li>Enter your username and password</li>
                                <li>You'll see your personal Ubuntu desktop environment</li>
                            </ul>
                        </div>
                        
                        <div class="step">
                            <strong>Pre-installed Software:</strong>
                            <ul>
                                <li>Firefox web browser</li>
                                <li>LibreOffice suite</li>
                                <li>Development tools (Git, Vim)</li>
                            </ul>
                        </div>
                    </div>
                    
                    <p style="margin-top: 30px;">
                        If you have any questions or need assistance, please contact IT support at 
                        <a href="mailto:it@innovatech.com">it@innovatech.com</a>
                    </p>
                    
                    <p>Welcome aboard!</p>
                    <p><strong>The Innovatech IT Team</strong></p>
                </div>
                
                <div class="footer">
                    <p>This is an automated message from Innovatech Employee Provisioning System</p>
                    <p>© {datetime.now().year} Innovatech Solutions</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        text_body = f"""
Welcome to Innovatech!

Hi {first_name},

Your dedicated virtual desktop has been provisioned!

YOUR LOGIN CREDENTIALS:
-----------------------
Username: {username}
Password: {password}
VPN Server: {OPENVPN_SERVER_IP}
Your Desktop Server: {private_ip}:3389

IMPORTANT: Your desktop may take 5-10 minutes to fully boot up.

HOW TO CONNECT:
---------------
1. Connect to VPN:
   - Download OpenVPN Connect from openvpn.net/client
   - Contact IT for your VPN configuration file
   - Import and connect to VPN

2. Connect to Your Desktop:
   - Open Microsoft Remote Desktop
   - Server: {private_ip}:3389
   - Login with your username and password

Need help? Contact IT: it@innovatech.com

Welcome aboard!
The Innovatech IT Team
        """
        
        response = ses.send_email(
            Source=SES_SENDER_EMAIL,
            Destination={
                'ToAddresses': [email]
            },
            Message={
                'Subject': {
                    'Data': subject,
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Text': {
                        'Data': text_body,
                        'Charset': 'UTF-8'
                    },
                    'Html': {
                        'Data': html_body,
                        'Charset': 'UTF-8'
                    }
                }
            }
        )
        
        print(f"Email sent successfully. Message ID: {response['MessageId']}")
        return True
        
    except Exception as e:
        print(f"Error sending email: {str(e)}")
        return False

def update_employee_status(employee_id, processed=True, instance_id=None, private_ip=None):
    """
    Update employee record in DynamoDB with instance info
    """
    try:
        update_expression = 'SET processed = :proc, processed_at = :timestamp'
        expression_values = {
            ':proc': {'BOOL': processed},
            ':timestamp': {'S': datetime.utcnow().isoformat()}
        }
        
        if instance_id:
            update_expression += ', instance_id = :inst'
            expression_values[':inst'] = {'S': instance_id}
        
        if private_ip:
            update_expression += ', private_ip = :ip'
            expression_values[':ip'] = {'S': private_ip}
        
        dynamodb.update_item(
            TableName=DYNAMODB_TABLE,
            Key={
                'id': {'S': employee_id}
            },
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_values
        )
        return True
    except Exception as e:
        print(f"Error updating employee status: {str(e)}")
        return False